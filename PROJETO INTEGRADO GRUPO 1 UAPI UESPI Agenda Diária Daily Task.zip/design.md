# Daily Task - Design Visual

## Filosofia de Design
- **Minimalismo funcional**: Interface limpa e focada na produtividade
- **Cores suaves**: Paleta harmoniosa que reduz a fadiga visual
- **Tipografia clara**: Fontes legíveis para leitura confortável
- **Ícones intuitivos**: Design consistente e reconhecível

## Paleta de Cores
- **Cor primária**: Azul profissional (#2563EB) - confiança e produtividade
- **Cor secundária**: Verde suave (#10B981) - sucesso e conclusão
- **Cor de alerta**: Laranja suave (#F59E0B) - lembretes e urgência
- **Fundo**: Branco e cinza claro (#F8FAFC, #F1F5F9)
- **Texto**: Cinza escuro (#1F2937) para contraste adequado

## Tipografia
- **Fonte principal**: Inter (sans-serif moderna)
- **Títulos**: Peso 600-700, tamanhos 20-28px
- **Corpo**: Peso 400-500, tamanhos 14-16px
- **Legenda**: Peso 400, tamanhos 12-14px

## Elementos Visuais
- **Cards arredondados**: Bordas de 12px para suavidade
- **Sombras sutis**: Profundidade sem excesso
- **Botões prominentes**: Alto contraste e fácil acesso
- **Animações suaves**: Transições de 200-300ms

## Layout Mobile
- **Navegação inferior**: Fácil acesso com o polegar
- **Espaçamento generoso**: 16-24px entre elementos
- **Touch targets**: Mínimo de 44px para acessibilidade
- **Scroll vertical**: Fluído e sem fricção