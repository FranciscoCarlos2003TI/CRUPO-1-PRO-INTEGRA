// Daily Task - Main JavaScript File

class DailyTaskApp {
    constructor() {
        this.tasks = this.loadTasks();
        this.notifications = [];
        this.currentFilter = 'all';
        this.editingTaskId = null;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.updateCurrentDate();
        this.renderTasks();
        this.updateStats();
        this.setupNotifications();
        this.requestNotificationPermission();
        
        // Initialize with sample data if empty
        if (this.tasks.length === 0) {
            this.addSampleTasks();
        }
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                const page = e.currentTarget.dataset.page;
                if (page && page !== 'index.html') {
                    this.navigateTo(page);
                }
            });
        });

        // Add task button
        const addTaskBtn = document.getElementById('addTaskBtn');
        if (addTaskBtn) {
            addTaskBtn.addEventListener('click', () => this.openAddTaskModal());
        }

        // Modal controls
        const modal = document.getElementById('taskModal');
        const closeModal = document.getElementById('closeModal');
        const cancelBtn = document.getElementById('cancelBtn');
        const taskForm = document.getElementById('taskForm');

        if (closeModal) {
            closeModal.addEventListener('click', () => this.closeModal());
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => this.closeModal());
        }

        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModal();
                }
            });
        }

        if (taskForm) {
            taskForm.addEventListener('submit', (e) => this.handleTaskSubmit(e));
        }

        // Quick action buttons
        const workTasksBtn = document.getElementById('workTasksBtn');
        const personalTasksBtn = document.getElementById('personalTasksBtn');
        const studyTasksBtn = document.getElementById('studyTasksBtn');

        if (workTasksBtn) {
            workTasksBtn.addEventListener('click', () => this.filterByCategory('work'));
        }

        if (personalTasksBtn) {
            personalTasksBtn.addEventListener('click', () => this.filterByCategory('personal'));
        }

        if (studyTasksBtn) {
            studyTasksBtn.addEventListener('click', () => this.filterByCategory('study'));
        }

        // Notification button
        const notificationBtn = document.getElementById('notificationBtn');
        if (notificationBtn) {
            notificationBtn.addEventListener('click', () => this.showNotifications());
        }
    }

    // Task Management
    addTask(taskData) {
        const task = {
            id: Date.now().toString(),
            title: taskData.title,
            description: taskData.description || '',
            date: taskData.date,
            time: taskData.time || '',
            category: taskData.category,
            priority: taskData.priority || 'medium',
            completed: false,
            reminder: taskData.reminder || false,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        this.tasks.push(task);
        this.saveTasks();
        this.renderTasks();
        this.updateStats();
        
        if (task.reminder && task.date && task.time) {
            this.scheduleNotification(task);
        }

        this.showToast('Tarefa adicionada com sucesso!');
        return task;
    }

    updateTask(taskId, updates) {
        const taskIndex = this.tasks.findIndex(task => task.id === taskId);
        if (taskIndex !== -1) {
            this.tasks[taskIndex] = {
                ...this.tasks[taskIndex],
                ...updates,
                updatedAt: new Date().toISOString()
            };
            
            this.saveTasks();
            this.renderTasks();
            this.updateStats();
            
            if (updates.reminder && this.tasks[taskIndex].date && this.tasks[taskIndex].time) {
                this.scheduleNotification(this.tasks[taskIndex]);
            }
            
            this.showToast('Tarefa atualizada com sucesso!');
        }
    }

    deleteTask(taskId) {
        this.tasks = this.tasks.filter(task => task.id !== taskId);
        this.saveTasks();
        this.renderTasks();
        this.updateStats();
        this.showToast('Tarefa excluída com sucesso!');
    }

    toggleTaskComplete(taskId) {
        const task = this.tasks.find(t => t.id === taskId);
        if (task) {
            this.updateTask(taskId, { completed: !task.completed });
        }
    }

    // Data Persistence
    loadTasks() {
        try {
            const stored = localStorage.getItem('dailyTasks');
            return stored ? JSON.parse(stored) : [];
        } catch (error) {
            console.error('Error loading tasks:', error);
            return [];
        }
    }

    saveTasks() {
        try {
            localStorage.setItem('dailyTasks', JSON.stringify(this.tasks));
        } catch (error) {
            console.error('Error saving tasks:', error);
        }
    }

    // Rendering
    renderTasks() {
        const tasksList = document.getElementById('tasksList');
        const emptyState = document.getElementById('emptyState');
        
        if (!tasksList || !emptyState) return;

        const today = new Date().toISOString().split('T')[0];
        const todayTasks = this.getTodayTasks();

        if (todayTasks.length === 0) {
            tasksList.style.display = 'none';
            emptyState.style.display = 'block';
        } else {
            tasksList.style.display = 'flex';
            emptyState.style.display = 'none';
            
            tasksList.innerHTML = todayTasks.map(task => this.createTaskHTML(task)).join('');
            
            // Add event listeners to task items
            this.attachTaskEventListeners();
        }

        // Render upcoming tasks
        this.renderUpcomingTasks();
    }

    createTaskHTML(task) {
        const timeFormatted = task.time ? this.formatTime(task.time) : '';
        const categoryClass = task.category || 'other';
        
        return `
            <div class="task-item ${task.completed ? 'completed' : ''}" data-task-id="${task.id}">
                <div class="task-checkbox ${task.completed ? 'checked' : ''}" data-action="toggle">
                    ${task.completed ? '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg>' : ''}
                </div>
                <div class="task-content">
                    <div class="task-title">${this.escapeHtml(task.title)}</div>
                    <div class="task-meta">
                        ${timeFormatted ? `<div class="task-time"><svg class="icon" style="width: 12px; height: 12px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12,6 12,12 16,14"></polyline></svg> ${timeFormatted}</div>` : ''}
                        <div class="task-category ${categoryClass}">${this.getCategoryName(task.category)}</div>
                    </div>
                </div>
                <div class="task-actions">
                    <button class="task-action-btn" data-action="edit" title="Editar">
                        <svg class="icon" style="width: 16px; height: 16px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                    </button>
                    <button class="task-action-btn" data-action="delete" title="Excluir">
                        <svg class="icon" style="width: 16px; height: 16px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3,6 5,6 21,6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                    </button>
                </div>
            </div>
        `;
    }

    attachTaskEventListeners() {
        document.querySelectorAll('.task-item').forEach(item => {
            const taskId = item.dataset.taskId;
            
            // Toggle completion
            const checkbox = item.querySelector('[data-action="toggle"]');
            if (checkbox) {
                checkbox.addEventListener('click', () => this.toggleTaskComplete(taskId));
            }
            
            // Edit task
            const editBtn = item.querySelector('[data-action="edit"]');
            if (editBtn) {
                editBtn.addEventListener('click', () => this.editTask(taskId));
            }
            
            // Delete task
            const deleteBtn = item.querySelector('[data-action="delete"]');
            if (deleteBtn) {
                deleteBtn.addEventListener('click', () => this.deleteTask(taskId));
            }
        });
    }

    renderUpcomingTasks() {
        const upcomingList = document.getElementById('upcomingList');
        if (!upcomingList) return;

        const upcomingTasks = this.getUpcomingTasks().slice(0, 5);

        if (upcomingTasks.length === 0) {
            upcomingList.innerHTML = '<div class="empty-state" style="padding: 20px;"><p class="empty-text">Nenhuma tarefa próxima</p></div>';
            return;
        }

        upcomingList.innerHTML = upcomingTasks.map(task => {
            const date = new Date(task.date);
            const day = date.getDate();
            const month = date.toLocaleDateString('pt-BR', { month: 'short' });
            
            return `
                <div class="upcoming-item">
                    <div class="upcoming-date">
                        <div class="upcoming-day">${day}</div>
                        <div class="upcoming-month">${month}</div>
                    </div>
                    <div class="upcoming-content">
                        <div class="upcoming-title">${this.escapeHtml(task.title)}</div>
                        <div class="upcoming-time">
                            ${task.time ? this.formatTime(task.time) : 'Sem horário'}
                            ${task.category ? `• ${this.getCategoryName(task.category)}` : ''}
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    // Statistics
    updateStats() {
        const todayTasks = this.getTodayTasks();
        const totalTasks = todayTasks.length;
        const completedTasks = todayTasks.filter(task => task.completed).length;
        const pendingTasks = totalTasks - completedTasks;

        const totalElement = document.getElementById('totalTasks');
        const completedElement = document.getElementById('completedTasks');
        const pendingElement = document.getElementById('pendingTasks');

        if (totalElement) totalElement.textContent = totalTasks;
        if (completedElement) completedElement.textContent = completedTasks;
        if (pendingElement) pendingElement.textContent = pendingTasks;
    }

    // Date and Time Utilities
    updateCurrentDate() {
        const currentDateElement = document.getElementById('currentDate');
        if (currentDateElement) {
            const today = new Date();
            const options = { 
                day: 'numeric', 
                month: 'long',
                weekday: 'long'
            };
            currentDateElement.textContent = today.toLocaleDateString('pt-BR', options);
        }
    }

    formatTime(time) {
        const [hours, minutes] = time.split(':');
        return `${hours}:${minutes}`;
    }

    getTodayTasks() {
        const today = new Date().toISOString().split('T')[0];
        return this.tasks.filter(task => task.date === today);
    }

    getUpcomingTasks() {
        const today = new Date().toISOString().split('T')[0];
        return this.tasks
            .filter(task => task.date > today)
            .sort((a, b) => new Date(a.date) - new Date(b.date));
    }

    // Modal Management
    openAddTaskModal(task = null) {
        const modal = document.getElementById('taskModal');
        const modalTitle = document.getElementById('modalTitle');
        const taskForm = document.getElementById('taskForm');
        
        if (!modal || !modalTitle || !taskForm) return;

        if (task) {
            modalTitle.textContent = 'Editar Tarefa';
            this.editingTaskId = task.id;
            
            // Populate form with task data
            document.getElementById('taskTitle').value = task.title;
            document.getElementById('taskDescription').value = task.description || '';
            document.getElementById('taskDate').value = task.date;
            document.getElementById('taskTime').value = task.time || '';
            document.getElementById('taskCategory').value = task.category;
            document.getElementById('taskPriority').value = task.priority;
            document.getElementById('taskReminder').checked = task.reminder || false;
        } else {
            modalTitle.textContent = 'Nova Tarefa';
            this.editingTaskId = null;
            taskForm.reset();
            
            // Set today's date as default
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('taskDate').value = today;
        }

        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    closeModal() {
        const modal = document.getElementById('taskModal');
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
        this.editingTaskId = null;
    }

    handleTaskSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const taskData = {
            title: document.getElementById('taskTitle').value.trim(),
            description: document.getElementById('taskDescription').value.trim(),
            date: document.getElementById('taskDate').value,
            time: document.getElementById('taskTime').value,
            category: document.getElementById('taskCategory').value,
            priority: document.getElementById('taskPriority').value,
            reminder: document.getElementById('taskReminder').checked
        };

        if (!taskData.title || !taskData.date) {
            this.showToast('Por favor, preencha o título e a data da tarefa.', 'error');
            return;
        }

        if (this.editingTaskId) {
            this.updateTask(this.editingTaskId, taskData);
        } else {
            this.addTask(taskData);
        }

        this.closeModal();
    }

    editTask(taskId) {
        const task = this.tasks.find(t => t.id === taskId);
        if (task) {
            this.openAddTaskModal(task);
        }
    }

    // Filtering
    filterByCategory(category) {
        this.currentFilter = category;
        this.navigateTo('tasks.html', { filter: category });
    }

    // Notifications
    async requestNotificationPermission() {
        if ('Notification' in window) {
            const permission = await Notification.requestPermission();
            if (permission === 'granted') {
                console.log('Notification permission granted');
            }
        }
    }

    scheduleNotification(task) {
        if (!('Notification' in window) || Notification.permission !== 'granted') {
            return;
        }

        const taskDateTime = new Date(`${task.date}T${task.time || '00:00'}`);
        const now = new Date();
        const timeUntilTask = taskDateTime.getTime() - now.getTime();

        if (timeUntilTask > 0) {
            // Schedule notification 15 minutes before task
            const notificationTime = Math.max(timeUntilTask - (15 * 60 * 1000), 0);
            
            setTimeout(() => {
                this.showTaskNotification(task);
            }, notificationTime);
        }
    }

    showTaskNotification(task) {
        if ('Notification' in window && Notification.permission === 'granted') {
            const notification = new Notification(`Lembrete: ${task.title}`, {
                body: task.description || 'Você tem uma tarefa agendada para agora.',
                icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%232563EB"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>',
                tag: `task-${task.id}`,
                requireInteraction: true
            });

            notification.onclick = () => {
                window.focus();
                notification.close();
            };

            this.addNotification({
                id: Date.now().toString(),
                title: task.title,
                message: 'Lembrete de tarefa',
                timestamp: new Date().toISOString(),
                taskId: task.id
            });
        }
    }

    addNotification(notification) {
        this.notifications.unshift(notification);
        this.updateNotificationBadge();
    }

    updateNotificationBadge() {
        const badge = document.getElementById('notificationBadge');
        if (badge) {
            const unreadCount = this.notifications.filter(n => !n.read).length;
            badge.textContent = unreadCount;
            badge.style.display = unreadCount > 0 ? 'block' : 'none';
        }
    }

    showNotifications() {
        if (this.notifications.length === 0) {
            this.showToast('Nenhuma notificação pendente');
            return;
        }

        // Mark all as read
        this.notifications.forEach(n => n.read = true);
        this.updateNotificationBadge();
        
        this.showToast(`${this.notifications.length} notificações visualizadas`);
    }

    setupNotifications() {
        // Check for due tasks every minute
        setInterval(() => {
            this.checkDueTasks();
        }, 60000);

        this.checkDueTasks();
    }

    checkDueTasks() {
        const now = new Date();
        const today = now.toISOString().split('T')[0];
        const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

        const dueTasks = this.tasks.filter(task => {
            if (task.completed || !task.reminder) return false;
            
            if (task.date < today) return true;
            if (task.date === today && task.time && task.time <= currentTime) return true;
            
            return false;
        });

        dueTasks.forEach(task => {
            if (!task.notificationShown) {
                this.showTaskNotification(task);
                task.notificationShown = true;
                this.updateTask(task.id, { notificationShown: true });
            }
        });
    }

    // Utility Functions
    navigateTo(page, params = {}) {
        const url = new URL(page, window.location.href);
        Object.keys(params).forEach(key => {
            url.searchParams.set(key, params[key]);
        });
        window.location.href = url.toString();
    }

    getCategoryName(category) {
        const categories = {
            work: 'Trabalho',
            personal: 'Pessoal',
            study: 'Estudos',
            health: 'Saúde',
            other: 'Outros'
        };
        return categories[category] || 'Outros';
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    showToast(message, type = 'success') {
        const toast = document.getElementById('toast');
        const toastMessage = document.getElementById('toastMessage');
        
        if (!toast || !toastMessage) return;

        toastMessage.textContent = message;
        toast.classList.add('show');

        if (type === 'error') {
            toast.style.borderColor = '#EF4444';
            toast.style.color = '#EF4444';
        } else {
            toast.style.borderColor = '#2563EB';
            toast.style.color = '#2563EB';
        }

        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }

    addSampleTasks() {
        const today = new Date().toISOString().split('T')[0];
        const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0];
        
        const sampleTasks = [
            {
                title: 'Reunião de equipe',
                description: 'Reunião semanal com a equipe de desenvolvimento',
                date: today,
                time: '09:00',
                category: 'work',
                priority: 'high',
                reminder: true
            },
            {
                title: 'Comprar mantimentos',
                description: 'Lista de compras: pão, leite, ovos, frutas',
                date: today,
                time: '18:00',
                category: 'personal',
                priority: 'medium',
                reminder: true
            },
            {
                title: 'Estudar JavaScript',
                description: 'Módulo 5 do curso de JavaScript avançado',
                date: tomorrow,
                time: '20:00',
                category: 'study',
                priority: 'medium',
                reminder: true
            }
        ];

        sampleTasks.forEach(task => this.addTask(task));
    }
}

// Global functions for HTML onclick handlers
function navigateTo(page) {
    window.location.href = page;
}

function openAddTaskModal() {
    if (window.dailyTaskApp) {
        window.dailyTaskApp.openAddTaskModal();
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.dailyTaskApp = new DailyTaskApp();
});

// Service Worker Registration for PWA functionality
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}